<?php
/** @var mysqli $koneksi */
    include "../config/koneksidbpegawai.php";
session_start();

if(!isset($_SESSION['Hak_Akses']) || $_SESSION['Hak_Akses'] != 'admin'){
    header("Location: ../index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">

<style>
        * { margin: 0; 
        padding: 0; 
        box-sizing: border-box; 
        }

        body { 
            font-family: 'Segoe UI'; 
            background: #f5f7fa;
        }

        .sidebar {
            position: fixed;
            width: 280px;
            height: 100vh;
            background: linear-gradient(#667eea, #02005a);
            color: white;
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
        }

        .sidebar-header h2 {
            margin-bottom: 8px;
        }

        .menu-item {
            display: block;
            padding: 18px 25px;
            color: white;
            text-decoration: none;
            font-weight: 500;
        }

        .main-content {
            margin-left: 280px;
            padding: 30px;      
        }

        .topbar {
            background: white;
            padding: 25px 35px;
            border-radius: 20px;
            margin-bottom: 35px;
            display: flex;
            align-items: center;
        }

        .topbar p {
            margin: 5px;
        }


.table-responsive {
    background: white;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    margin-top:50px;
}

.table {
    min-width: 1200px ;
}

    </style>
    </head>
<body>
     <div class="sidebar">
        <div class="sidebar-header">
            <h2> Kepegawaian</h2>
        </div>
        <div class="sidebar-menu">
            <a href="index_Admin.php" class="menu-item active">Dashboard</a>
            <a href="data_Pegawai.php" class="menu-item">Data Karyawan</a>
            <a href="absensi.php" class="menu-item">Data Absensi</a>
            <a href="jabatan.php" class="menu-item">Jabatan</a>
            <a href="gaji.php" class="menu-item">Gaji</a>
            <a href="../logout.php" class="menu-item"> Logout</a>
        </div>
    </div>

    
    <div class="main-content">
        <div class="topbar">
            <div>
                <h1>Dashboard</h1>
                <p>Selamat datang!</p>
            </div>
        </div>

    
        <h2>DATA KARYAWAN</h2>


        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambah_karyawan">
            Tambah data karyawan
        </button>

        <?php
        include "modal/add_pegawai.php"?>
        
           <div class="table-responsive" >
    <table class="table table-striped table-hover table-bordered">
                <thead>
                <tr>
                    <th>ID Pegawai</th>
                    <th>NIK</th>
                    <th>Nama</th>
                    <th>Tanggal lahir</th>
                    <th>Alamat</th>
                    <th>Gender</th>
                    <th>Agama</th>
                    <th>No_Telepon</th>
                    <th>Email</th>
                    <th>Jabatan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                    $sql = "SELECT * FROM identitas_pegawai ORDER BY Nama ASC";
                    $hasil = mysqli_query($koneksi, $sql);
                    while ($data = mysqli_fetch_assoc($hasil)){
                ?>
                    <tr>
                        
                        <td><?= $data['ID_Pegawai'] ?></td>
                        <td><?= $data['NIK'] ?></td>
                        <td><?= $data['Nama'] ?></td>
                        <td><?= $data['TTL'] ?></td>
                        <td><?= $data['Alamat'] ?></td>
                        <td><?= $data['Gender'] ?></td>
                        <td><?= $data['Agama'] ?></td>
                        <td><?= $data['No_Telepon'] ?></td>
                        <td><?= $data['Email'] ?></td>
                        <td><?= $data['Jabatan'] ?></td>
                       <td>
                        <button type="button" class="btn btn-sm btn-primary edit-btn"
            data-bs-toggle="modal" 
            data-bs-target="#edit_karyawan"
            data-bs-id="<?= $data['ID_Pegawai'] ?>"
            data-bs-nik="<?= str_replace("'", "\'", $data['NIK']) ?>"
            data-bs-nama="<?= str_replace("'", "\'", $data['Nama']) ?>"
            data-bs-ttl="<?= str_replace("'", "\'", $data['TTL']) ?>"
            data-bs-alamat="<?= str_replace("'", "\'", $data['Alamat']) ?>"
            data-bs-gender="<?= $data['Gender'] ?>"
            data-bs-agama="<?= $data['Agama'] ?>"
            data-bs-telepon="<?= str_replace("'", "\'", $data['No_Telepon']) ?>"
            data-bs-email="<?= str_replace("'", "\'", $data['Email']) ?>">
        <i class="fas fa-edit"></i> Edit
    </button>

                            <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" 
                            data-bs-target="#hapus<?= $data['ID_Pegawai'] ?>">Hapus</button>
                        </td>
                    </tr>
                    <?php
                    include "modal/delete_pegawai.php";
                    }
                    ?>    
            </tbody>
        </table>

</div>
<?php
include "modal/edit_pegawai.php";
?>

</div>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script>
        var editModal = document.getElementById('edit_karyawan'); 
        editModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget;
        document.getElementById('edit_ID_Pegawai').value = button.getAttribute('data-bs-id');
        document.getElementById('edit_ID_Pegawai_display').value = button.getAttribute('data-bs-id');
        document.getElementById('edit_NIK').value = button.getAttribute('data-bs-nik');
        document.getElementById('edit_Nama').value = button.getAttribute('data-bs-nama');
        document.getElementById('edit_TTL').value = button.getAttribute('data-bs-ttl');
        document.getElementById('edit_Alamat').value = button.getAttribute('data-bs-alamat');
        document.getElementById('edit_Gender').value = button.getAttribute('data-bs-gender');
        document.getElementById('edit_Agama').value = button.getAttribute('data-bs-agama');
        document.getElementById('edit_No_Telepon').value = button.getAttribute('data-bs-telepon');
        document.getElementById('edit_Email').value = button.getAttribute('data-bs-email');
    });
    </script>
</body>

</html>