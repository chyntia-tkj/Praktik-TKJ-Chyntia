<?php
include "../config/koneksidbpegawai.php";
session_start();

if(!isset($_SESSION['Hak_Akses']) || $_SESSION['Hak_Akses'] != 'admin'){
    header("Location: ../index.php");
    exit();
}

// potongan rate per hari
$rate = 50000;

// AJAX endpoint for potongan calculation
if(isset($_GET['ajax']) && $_GET['ajax'] == 'potongan' && isset($_GET['ID_Pegawai']) && isset($_GET['tanggal'])){
    $id_pegawai = mysqli_real_escape_string($koneksi, $_GET['ID_Pegawai']);
    $tanggal = $_GET['tanggal'];
    $year = date('Y', strtotime($tanggal));
    $month = date('m', strtotime($tanggal));

    $query = "SELECT COUNT(*) AS total FROM absensi WHERE ID_Pegawai = ? AND YEAR(Tanggal) = ? AND MONTH(Tanggal) = ? AND Status <> 'Hadir'";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, 'sss', $id_pegawai, $year, $month);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    $days = (int)($row['total'] ?? 0);
    $potongan = $days * $rate;

    header('Content-Type: application/json');
    echo json_encode(['potongan' => $potongan, 'days' => $days, 'rate' => $rate, 'month' => date('F Y', strtotime($tanggal))]);
    exit;
}

if(isset($_POST['simpan_gaji'])) {
    if(empty($_POST['ID_Pegawai']) || empty($_POST['tanggal'])) {
        echo "<script>alert('Lengkapi Nama Pegawai & Tanggal!'); </script>";
        exit();
    }

    $gaji_pokok = (float)$_POST['gaji_pokok'];
    $tunjangan = (float)($_POST['tunjangan'] ?? 0);
    $potongan = (float)($_POST['potongan_absen'] ?? 0);
    $total_gaji = (float)$_POST['total_gaji'];
    $id_pegawai = mysqli_real_escape_string($koneksi, $_POST['ID_Pegawai']); 
    $tanggal = $_POST['tanggal'];        

    $cek_duplikat = "SELECT COUNT(*) as total FROM gaji WHERE ID_Pegawai = '$id_pegawai' AND Tanggal = '$tanggal'";
    $cek_result = mysqli_query($koneksi, $cek_duplikat);
    $cek_data = mysqli_fetch_assoc($cek_result);
    
    if($cek_data['total'] > 0) {
        echo "<script>alert('Data gaji untuk pegawai ini pada tanggal $tanggal sudah ada!'); </script>";
    } else {
        $sql = "SELECT Nama FROM identitas_pegawai WHERE ID_Pegawai = '$id_pegawai'";
        $result = mysqli_query($koneksi, $sql);
        
        if($row = mysqli_fetch_assoc($result)) {
                        $nama_pegawai = mysqli_real_escape_string($koneksi, $row['Nama']);

            
            $insert_sql = "INSERT INTO gaji (ID_Pegawai, Nama, Tanggal, gaji_pokok, Tunjangan, potongan, Total_Gaji) VALUES ('$id_pegawai', '$nama_pegawai', '$tanggal', '$gaji_pokok', '$tunjangan', '$potongan', '$total_gaji');";
            
            if(mysqli_query($koneksi, $insert_sql)) {
                echo "<script>alert('Gaji berhasil disimpan!'); window.location.reload();</script>";
            } else {
                echo "<script>alert(' Error: " . mysqli_error($koneksi) . "');</script>";
            }
        } else {
            echo "<script>alert(' ID Pegawai tidak valid!');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Kepegawaian</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        * { margin: 0; 
        padding: 0; 
        box-sizing: border-box; 
        }

        body { 
            font-family: 'Segoe UI'; 
            background: #f5f7fa;
        }

        .sidebar {
            position: fixed;
            width: 280px;
            height: 100vh;
            background: linear-gradient(#667eea, #02005a);
            color: white;
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
        }

        .sidebar-header h2 {
            margin-bottom: 8px;
        }

        .menu-item {
            display: block;
            padding: 18px 25px;
            color: white;
            text-decoration: none;
            font-weight: 500;
        }

        .main-content {
            margin-left: 280px;
            padding: 30px;      
        }

        .topbar {
            background: white;
            padding: 25px 35px;
            border-radius: 20px;
            margin-bottom: 35px;
            display: flex;
            align-items: center;
        }

        .topbar p {
            margin: 5px;
        }


.table-responsive {
    background: white;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    margin-top:50px;
}

.table {
    min-width: 1200px ;
}

    </style>
    </head>
<body>
     <div class="sidebar">
        <div class="sidebar-header">
            <h2> Kepegawaian</h2>
        </div>
        <div class="sidebar-menu">
            <a href="index_Admin.php" class="menu-item active">Dashboard</a>
            <a href="data_Pegawai.php" class="menu-item">Data Karyawan</a>
            <a href="absensi.php" class="menu-item">Data Absensi</a>
            <a href="jabatan.php" class="menu-item">Jabatan</a>
            <a href="gaji.php" class="menu-item">Gaji</a>
            <a href="../logout.php" class="menu-item"> Logout</a>
        </div>
    </div>

    
    <div class="main-content">
        <div class="topbar">
            <div>
                <h1>Dashboard</h1>
                <p>Selamat datang!</p>
            </div>
        </div>

        
            <h2>RIWAYAT GAJI</h2>
            
        <div class="d-flex justify-content-between align-items-center mb-4">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambah_gaji">
                <i class="fas fa-plus"></i> Tambah Data Gaji
            </button>
        </div>
    

        <div class="modal fade" id="tambah_gaji" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form method="post">
                        <div class="modal-header bg-primary text-white">
                            <h5 class="modal-title">Tambah Data Gaji</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-bold">Pilih Pegawai <span class="text-danger">*</span></label>
                                    <select name="ID_Pegawai" id="pegawai_select" class="form-control" required onchange="pilihPegawai()">
                                        <option value="">-- Pilih Pegawai --</option>
                                        <?php
                                        $pegawai_sql = "SELECT identitas_pegawai.ID_Pegawai, identitas_pegawai.Nama, jabatan.Nama_Jabatan, jabatan.Gaji_Pokok 
                                                      FROM identitas_pegawai
                                                      INNER JOIN jabatan ON identitas_pegawai.Jabatan = jabatan.Nama_Jabatan 
                                                      ORDER BY identitas_pegawai.Nama";
                                        $pegawai_result = mysqli_query($koneksi, $pegawai_sql);
                                        while($p = mysqli_fetch_assoc($pegawai_result)):
                                        ?>
                                            <option value="<?= $p['ID_Pegawai'] ?>" 
                                                    data-nama="<?= $p['Nama'] ?>" 
                                                    data-jabatan="<?= $p['Nama_Jabatan'] ?>" 
                                                    data-gaji="<?= $p['Gaji_Pokok'] ?>">
                                                <?= $p['Nama'] ?> - <?= $p['Nama_Jabatan'] ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-bold">Tanggal <span class="text-danger">*</span></label>
                                    <input type="date" name="tanggal" id="tanggal" class="form-control" required>
                                </div>

                                <div id="info_pegawai" style="display:none;"> 
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-bold">Jabatan</label>
                                        <input type="text" id="jabatan_pegawai" class="form-control bg-light" readonly>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-bold">Gaji Pokok</label>
                                        <input type="text" id="gaji_pokok_display" class="form-control bg-light" readonly>
                                        <input type="hidden" name="gaji_pokok" id="gaji_pokok_hidden">
                                    </div>
                                </div>

                                <div class="col-md-6 mb-3" id="tunjangan_field" style="display:none;">
                                    <label class="form-label fw-bold">Tunjangan</label>
                                    <input type="number" name="tunjangan" id="tunjangan" class="form-control" value="0" min="0" step="1000" oninput="hitungTotal()">
                                </div>

                                <div class="col-md-6 mb-3" id="potongan_field" style="display:none;">
                                    <label class="form-label fw-bold">Potongan Absen</label>
                                    <input type="number" name="potongan_absen" id="potongan_absen" class="form-control" value="<?= isset($calc_potongan) ? $calc_potongan : 0 ?>" min="0" step="1000" readonly>
                                    <small id="potongan_note" class="text-muted"><?= isset($calc_days) ? ($calc_days . ' hari tidak hadir pada ' . (isset($tanggal) ? date('F Y', strtotime($tanggal)) : '') . ' — Rp ' . number_format($rate,0,',') . '/hari') : 'Rp 50.000/hari' ?></small>
                                </div>

                                <div class="col-12 mb-3" id="total_field" style="display:none;">
                                    <label class="">TOTAL GAJI</label>
                                    <input type="text" id="total_display" class="form-control" readonly>
                                    <input type="hidden" name="total_gaji" id="total_hidden">
                                </div>
                        </td>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" name="simpan_gaji" id="btn_submit" class="btn btn-primary btn-lg" disabled>
                                Simpan Gaji
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

     
        <div class="table-responsive">
            <table class="table table-striped table-hover table-bordered">
                <thead>
                    <tr>
                        <th class="py-3">No</th>
                        <th>ID Pegawai</th>
                        <th>Nama</th>
                        <th>Tanggal</th>
                        <th>Gaji Pokok</th>
                        <th>Tunjangan</th>
                        <th>Potongan</th>
                        <th>Total Gaji</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $sql = "SELECT gaji.*, identitas_pegawai.Nama 
                            FROM gaji 
                            INNER JOIN identitas_pegawai ON gaji.ID_Pegawai = identitas_pegawai.ID_Pegawai 
                            ORDER BY gaji.Tanggal DESC, gaji.ID_Pegawai";
                    $hasil = mysqli_query($koneksi, $sql);
                    if(mysqli_num_rows($hasil) > 0):
                        while($data = mysqli_fetch_assoc($hasil)):
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><strong><?= $data['ID_Pegawai'] ?></strong></td>
                        <td><?= $data['Nama'] ?></td>
                        <td><?= date('d/m/Y', strtotime($data['Tanggal'])) ?></td>
                        <td>Rp <?= number_format($data['gaji_pokok'],0,',') ?></td>
                        <td>Rp <?= number_format($data['Tunjangan'],0,',') ?></td>
                        <td>Rp <?= number_format($data['potongan'] ?? 0,0,',') ?></td>
                        <td class="fw-bold text-success fs-6">
                        Rp <?= number_format($data['Total_Gaji'],0,',') ?>
                        </td>
                        <td>
                            <?php $modal_target = 'hapus' . $data['ID_Pegawai'] . '_' . str_replace('-', '', $data['Tanggal']); ?>
                            <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" 
                                data-bs-target="#<?= $modal_target ?>">Hapus</button>
                        </td>
                    </tr>
                    <?php include __DIR__ . '/modal/hapusgajih.php'; ?>
                    <?php 
                        endwhile;
                    else:
                    ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
    function pilihPegawai() {
        const select = document.getElementById('pegawai_select');
        const value = select.value;
        const option = select.options[select.selectedIndex];
        
        if(value) {
            document.getElementById('jabatan_pegawai').value = option.dataset.jabatan;
            document.getElementById('gaji_pokok_display').value = 'Rp ' + parseInt(option.dataset.gaji).toLocaleString();
            document.getElementById('gaji_pokok_hidden').value = option.dataset.gaji;
            document.getElementById('info_pegawai').style.display = 'block';
            document.getElementById('tunjangan_field').style.display = 'block';
            document.getElementById('potongan_field').style.display = 'block';
            
            hitungPotonganAbsen(value);
            document.getElementById('btn_submit').disabled = false;
        } else {
            resetForm();
        }
    }
    
    function hitungPotonganAbsen(id_pegawai) {
        const tanggal = document.getElementById('tanggal').value || new Date().toISOString().split('T')[0];
        fetch(`gaji.php?ajax=potongan&ID_Pegawai=${encodeURIComponent(id_pegawai)}&tanggal=${encodeURIComponent(tanggal)}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('potongan_absen').value = data.potongan;
                document.getElementById('potongan_note').textContent = `${data.days} hari tidak hadir pada ${data.month} — Rp ${data.rate.toLocaleString()}/hari`;
                hitungTotal();
            })
            .catch(() => {
                document.getElementById('potongan_absen').value = 0;
                document.getElementById('potongan_note').textContent = 'Rp 50.000/hari';
                hitungTotal();
            });
    }
    
    function hitungTotal() {
        const gajiPokok = parseInt(document.getElementById('gaji_pokok_hidden').value) || 0;
        const tunjangan = parseInt(document.getElementById('tunjangan').value) || 0;
        const potongan = parseInt(document.getElementById('potongan_absen').value) || 0;
        const total = gajiPokok + tunjangan - potongan;
        
        document.getElementById('total_display').value = 'Rp ' + total.toLocaleString();
        document.getElementById('total_hidden').value = total;
        document.getElementById('total_field').style.display = 'block';
    }
    
    function resetForm() {
        document.getElementById('info_pegawai').style.display = 'none';
        document.getElementById('tunjangan_field').style.display = 'none';
        document.getElementById('potongan_field').style.display = 'none';
        document.getElementById('total_field').style.display = 'none';
        document.getElementById('btn_submit').disabled = true;
    }
    
    document.getElementById('tanggal').addEventListener('change', function() {
        const select = document.getElementById('pegawai_select');
        if(select.value) {
            hitungPotonganAbsen(select.value);
        }
    });
    
    document.getElementById('tambah_gaji').addEventListener('shown.bs.modal', function() {
        document.getElementById('tanggal').value = new Date().toISOString().split('T')[0];
        document.getElementById('pegawai_select').focus();
    });
    
    <?php if(isset($_GET['calc']) && $_GET['calc'] == '1'): ?>
    document.addEventListener('DOMContentLoaded', function() {
        var myModal = new bootstrap.Modal(document.getElementById('tambah_gaji'));
        myModal.show();
    });
    <?php endif; ?>
    </script>
</body>
</html>