 <div class="modal fade" id="tambah_absensi" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="action/add_absensi.php" method="POST">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title">Tambah Jabatan</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Pilih Karyawan</label>
                            <select name="ID_Pegawai" class="form-select" required>
                                <option value="-- Pilih Karyawan --"></option>
                                <?php
                                $sql2 = "SELECT ID_Pegawai, Nama FROM identitas_pegawai ORDER BY Nama ASC";
                                $hasil2 = mysqli_query($koneksi, $sql2);
                                while ($row = mysqli_fetch_assoc($hasil2)) {
                                    echo "<option value='" . $row['ID_Pegawai'] . "'>" . $row['Nama'] . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tanggal</label>
                            <input type="date" name="Tanggal" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select name="Status" class="form-select" required>
                                <option value="Hadir">Hadir</option>
                                <option value="Sakit">Sakit</option>
                                <option value="Izin">Izin</option>
                                <option value="Alfa">Alfa</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>