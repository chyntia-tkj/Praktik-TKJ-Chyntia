
<div class="modal fade" id="tambah_karyawan" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="action/action_add.php" method="post">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="exampleModalLabel">
                        <i class="fas fa-user-plus me-2"></i>Form Tambah Data Pegawai
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">NIK</label>
                            <input type="text" name="NIK" class="form-control" required minlength="16" maxlength="16" pattern="[0-9]{16}" title="NIK harus 16 digit angka">
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">Nama Pegawai</label>
                            <input type="text" name="Nama" class="form-control" required>
                        </div>
                        <!-- <div class="col-md-3 mb-3">
                            <label class="form-label">Tempat</label>
                            <input type="text" name="Alamat" class="form-control" required>
                        </div> -->
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Lahir</label>
                            <input type="date" name="TTL" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Alamat</label>
                            <input type="text" name="Alamat" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Gender</label>
                            <select name="Gender" class="form-select" required>
                                <option value="">Pilih Gender</option>
                                <option value="Pria">Pria</option>
                                <option value="Wanita">Wanita</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Agama</label>
                            <select name="Agama" class="form-select" required>
                                <option value="">Pilih Agama</option>
                                <option value="Islam">Islam</option>
                                <option value="Kristen">Kristen</option>
                                <option value="Katolik">Katolik</option>
                                <option value="Hindu">Hindu</option>
                                <option value="Buddha">Buddha</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">No. Telepon</label>
                            <input type="text" name="No_Telepon" class="form-control" required minlength="10" maxlength="13" pattern="[0-9]{10,13}" title="No. Telepon harus 10 sampai 13 digit angka">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="Email" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" name="Username" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="Password" class="form-control" required>
                        </div>
                        <input type="hidden" name="Hak_Akses" value="karyawan">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Jabatan</label>
                            <select name="jabatan" class="form-select" required>
                                <option value="">Pilih Jabatan</option>
                                <?php
                                $sql = "SELECT * FROM Jabatan";
                                $hasil = mysqli_query($koneksi, $sql);
                                while ($data = mysqli_fetch_assoc($hasil)){
                                ?>
                                    <option value=<?= $data['Nama_Jabatan'] ?>><?= $data['Nama_Jabatan'] ?></option>
                             <?php
                                }?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i>Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>