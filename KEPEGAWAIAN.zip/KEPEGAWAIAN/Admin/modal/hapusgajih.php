
<?php $modal_id = 'hapus' . $data['ID_Pegawai'] . '_' . str_replace('-', '', $data['Tanggal']); ?>
<div class="modal fade" id="<?= $modal_id ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5>Konfirmasi Hapus</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Yakin hapus <?= $data['Nama'] ?> (<?= $data['ID_Pegawai'] ?>)?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <form method="POST" action="./action/aksihapusgajih.php" style="display: inline;">
                    <input type="hidden" name="hapus_id" value="<?= $data['ID_Pegawai'] ?>">
                    <input type="hidden" name="hapus_tanggal" value="<?= $data['Tanggal'] ?>">
                    <button type="submit" name="hapus" class="btn btn-danger">
                        <i class="fas fa-trash"></i> Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>