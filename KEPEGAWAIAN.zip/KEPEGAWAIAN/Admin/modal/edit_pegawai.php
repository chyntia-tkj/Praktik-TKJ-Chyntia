
<div class="modal fade" id="edit_karyawan" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="action/action_edit.php" method="post">
                <div class="modal-header bg-primary text-dark">
                    <h5 class="modal-title" id="editModalLabel">
                        <i class="fas fa-user-edit me-2"></i>Edit Data Pegawai
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="ID_Pegawai" id="edit_ID_Pegawai">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">ID Pegawai</label>
                            <input type="text" name="ID_Pegawai_display" id="edit_ID_Pegawai_display" class="form-control" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">NIK</label>
                            <input type="text" name="NIK" id="edit_NIK" class="form-control" required minlength="16" maxlength="16" pattern="\d{16}" inputmode="numeric" title="NIK harus 16 digit angka">
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">Nama Pegawai</label>
                            <input type="text" name="Nama" id="edit_Nama" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">TTL</label>
                            <input type="date" name="TTL" id="edit_TTL" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Alamat</label>
                            <input type="text" name="Alamat" id="edit_Alamat" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Gender</label>
                            <select name="Gender" id="edit_Gender" class="form-select" required>
                                <option value="">Pilih Gender</option>
                                <option value="Pria">Pria</option>
                                <option value="Wanita">Wanita</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Agama</label>
                            <select name="Agama" id="edit_Agama" class="form-select" required>
                                <option value="">Pilih Agama</option>
                                <option value="Islam">Islam</option>
                                <option value="Kristen">Kristen</option>
                                <option value="Katolik">Katolik</option>
                                <option value="Hindu">Hindu</option>
                                <option value="Buddha">Buddha</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">No. Telepon</label>
                            <input type="text" name="No_Telepon" id="edit_No_Telepon" class="form-control" required minlength>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="Email" id="edit_Email" class="form-control" required>
                        </div>
                        
                        
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i>Update Data
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>