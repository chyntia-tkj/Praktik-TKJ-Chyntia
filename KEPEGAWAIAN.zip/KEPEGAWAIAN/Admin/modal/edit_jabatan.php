<div class="modal fade" id="edit_jabatan" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="action/action_edit_jabatan.php" method="post">
                <div class="modal-header bg-primary text-dark">
                    <h5 class="modal-title" id="editModalLabel">
                        <i class="fas fa-user-edit me-2"></i>Edit Data Jabatan
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="ID_Pegawai" id="edit_ID_Pegawai">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">ID Pegawai</label>
                            <input type="text" name="ID_Pegawai" id="edit_ID_Pegawai_display" class="form-control" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nama Pegawai</label>
                            <input type="text" name="Nama" id="edit_Nama_pegawai" class="form-control" readonly>
                        </div>
                         <div class="col-md-6 mb-3">
                            <label class="form-label">Jabatan</label>
                            <select name="jabatan" id="edit_Nama_jabatan" class="form-select" required>
                                <option value="">Pilih Jabatan</option>
                                <?php
                                $sql = "SELECT * FROM Jabatan";
                                $hasil = mysqli_query($koneksi, $sql);
                                while ($data = mysqli_fetch_assoc($hasil)){
                                ?>
                                    <option value=<?= $data['Nama_Jabatan'] ?>><?= $data['Nama_Jabatan'] ?></option>
                             <?php
                                }?>
                            </select>
                        </div>
                        
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i>Update Data
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>