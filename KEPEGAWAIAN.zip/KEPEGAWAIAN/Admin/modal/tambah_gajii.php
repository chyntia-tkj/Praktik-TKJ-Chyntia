<div class="modal fade" id="tambah_gaji" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="" method="post">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Hitung Gaji Bulanan</h5>
                </div>
                <div class="modal-body">
                    <?php
                    $selected_id = $_POST['ID_Pegawai'] ?? '';
                    $selected_pegawai = null;
                    $hari_tidak_masuk = 0;
                    $total_potongan = 0;
                    
                    if($selected_id) {
                        $sql_pegawai = "SELECT identitas_pegawai.Nama, jabatan.Nama_Jabatan, jabatan.Gaji_Pokok 
                                       FROM identitas_pegawai
                                       INNER JOIN jabatan ON identitas_pegawai.Jabatan = jabatan.Nama_Jabatan 
                                       WHERE identitas_pegawai.ID_Pegawai = '$selected_id'";
                        $result_pegawai = mysqli_query($koneksi, $sql_pegawai);
                        $selected_pegawai = mysqli_fetch_assoc($result_pegawai);
                        
                        
                        $bulan_ini = date('Y-m');
                        $total_hari_kerja = 22;
                        $sql_absen = "SELECT COUNT(*) as masuk FROM absensi 
                                     WHERE ID_Pegawai = '$selected_id' 
                                     AND DATE_FORMAT(Tanggal, '%Y-%m') = '$bulan_ini'";
                        $result_absen = mysqli_query($koneksi, $sql_absen);
                        $absen_data = mysqli_fetch_assoc($result_absen);
                        
                        $hari_masuk = (int)$absen_data['masuk'];
                        $hari_tidak_masuk = max(0, $total_hari_kerja - $hari_masuk);
                        $potongan_per_hari = 100000;
                        $total_potongan = $hari_tidak_masuk * $potongan_per_hari;
                    }
                    ?>
                    
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label fw-bold">Pilih Pegawai *</label>
                            <select name="ID_Pegawai" class="form-control" required onchange="this.form.submit()">
                                <option value="">-- Pilih Pegawai --</option>
                                <?php
                                $pegawai_sql = "SELECT identitas_pegawai.ID_Pegawai, identitas_pegawai.Nama, jabatan.Nama_Jabatan, jabatan.Gaji_Pokok 
                                              FROM identitas_pegawai
                                              INNER JOIN jabatan ON identitas_pegawai.Jabatan = jabatan.Nama_Jabatan 
                                              ORDER BY identitas_pegawai.Nama";
                                $pegawai_result = mysqli_query($koneksi, $pegawai_sql);
                                while($pegawai = mysqli_fetch_assoc($pegawai_result)):
                                ?>
                                <option value="<?= $pegawai['ID_Pegawai'] ?>" 
                                        <?= ($selected_id == $pegawai['ID_Pegawai']) ? 'selected' : '' ?>>
                                    <?= $pegawai['Nama'] ?> - <?= $pegawai['Nama_Jabatan'] ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <?php if($selected_pegawai): ?>
                        <div class="col-12 mb-3 p-3 bg-success bg-opacity-10 border rounded">
                            <div class="row text-center">
                                <div class="col-md-3">
                                    <strong><?= $selected_pegawai['Nama'] ?></strong><br>
                                    <small><?= $selected_pegawai['Nama_Jabatan'] ?></small>
                                </div>
                                <div class="col-md-3">
                                    <strong class="text-success fs-4">Rp <?= number_format($selected_pegawai['Gaji_Pokok'],0,',') ?></strong><br>
                                    <small class="text-muted">Gaji Pokok/Bulan</small>
                                </div>
                                <div class="col-md-3 text-danger">
                                    <strong><?= $hari_tidak_masuk ?> Hari</strong><br>
                                    <small>Tidak Masuk</small>
                                </div>
                                <div class="col-md-3 text-danger">
                                    <strong class="fs-5">Rp <?= number_format($total_potongan,0,',') ?></strong><br>
                                    <small>Total Potongan</small>
                                </div>
                            </div>
                            <input type="hidden" name="gaji_pokok" value="<?= $selected_pegawai['Gaji_Pokok'] ?>">
                            <input type="hidden" name="hari_tidak_masuk" value="<?= $hari_tidak_masuk ?>">
                            <input type="hidden" name="potongan_gaji" value="<?= $total_potongan ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Tunjangan (Opsional)</label>
                            <input type="number" name="tunjangan" class="form-control" value="0" min="0" step="1000">
                        </div>

                        <?php 
                        $total_gaji = $selected_pegawai['Gaji_Pokok'] ?? 0;
                        $tunjangan = $_POST['tunjangan'] ?? 0;
                        $total_gaji = $total_gaji + (int)$tunjangan - $total_potongan;
                        ?>
                        
                        <div class="col-12 mb-3">
                            <label class="form-label fw-bold text-success fs-3">TOTAL GAJI</label>
                            <input type="text" class="form-control fs-2 fw-bold text-success bg-success text-white shadow-lg" 
                                   value="Rp <?= number_format($total_gaji,0,',') ?>" readonly>
                            <input type="hidden" name="total_gaji" value="<?= $total_gaji ?>">
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <?php if($selected_pegawai): ?>
                    <button type="submit" name="simpan_gaji" class="btn btn-success btn-lg">
                        <i class="fas fa-save"></i> Simpan Gaji
                    </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>