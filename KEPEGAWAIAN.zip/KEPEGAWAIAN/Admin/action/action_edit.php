<?php
/** @var mysqli $koneksi */
include '../../config/koneksidbpegawai.php';

if (isset($_POST['ID_Pegawai'])) {
    
$ID_Pegawai = $_POST['ID_Pegawai'];
$NIK = $_POST['NIK'];
$Nama = $_POST['Nama'];
$TTL = $_POST['TTL'];
$Alamat = $_POST['Alamat'];
$Gender = $_POST['Gender'];
$Agama = $_POST['Agama'];
$No_Telepon = $_POST['No_Telepon'];
$Email = $_POST['Email'];

$query = "UPDATE identitas_pegawai SET NIK='$NIK', Nama='$Nama', TTL='$TTL', Alamat='$Alamat', Gender='$Gender', Agama='$Agama', No_Telepon='$No_Telepon', Email='$Email' WHERE ID_Pegawai='$ID_Pegawai'";

$result = mysqli_query($koneksi, $query);

if ($result) {
    echo "<script>
    alert('Data pegawai berhasil diubah!');
    window.location.href = '../data_Pegawai.php';
    </script>";
} else {
    echo "<script>
    alert('Gagal menambahkan data siswa!');
    window.location.href = '../data_Pegawai.php';
    </script>";
}
}

?>