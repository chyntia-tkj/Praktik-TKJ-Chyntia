<?php
/** @var mysqli $koneksi */
include '../../config/koneksidbpegawai.php';

if (isset($_POST['Nama'])) {
    $NIK =$_POST['NIK'];
    $Nama =$_POST['Nama'];
    $TTL =$_POST['TTL'];
    $Alamat =$_POST['Alamat'];
    $Gender =$_POST['Gender'];
    $Agama =$_POST['Agama'];
    $No_Telepon =$_POST['No_Telepon'];
    $Email =$_POST['Email'];
    $Jabatan =$_POST['jabatan'];
    $Username =$_POST['Username'];
    $Password = md5($_POST['Password']);
    $Hak_Akses =$_POST['Hak_Akses'] ?? 'karyawan';

    $cek_user = "SELECT COUNT(*) AS total FROM karyawan WHERE Username = '$Username'";
    $user_result = mysqli_query($koneksi, $cek_user);
    $user_data = mysqli_fetch_assoc($user_result);

    if ($user_data['total'] > 0) {
        echo "<script>
        alert('Username sudah digunakan, gunakan username lain.');
        window.location.href = '../data_Pegawai.php';
        </script>";
        exit();
    }

    $query = "INSERT INTO identitas_pegawai (NIK, Nama, TTL, Alamat, Gender, Agama, No_Telepon, Email, Jabatan) VALUES ('$NIK', '$Nama', '$TTL', '$Alamat', '$Gender', '$Agama', '$No_Telepon', '$Email', '$Jabatan')";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        $insert_karyawan = "INSERT INTO karyawan (No, Nama, Jabatan, No_Telp, Username, Password, Hak_Akses) VALUES ('$No', '$Nama', '$Jabatan', '$No_Telepon', '$Username', '$Password', '$Hak_Akses')";
        if (mysqli_query($koneksi, $insert_karyawan)) {
            echo "<script>
            alert('Data pegawai berhasil ditambahkan!');
            window.location.href = '../data_Pegawai.php';
            </script>";
        } else {
            echo "<script>
            alert('Gagal menambahkan data karyawan');
            window.location.href = '../data_Pegawai.php';
            </script>";
        }
    } else {
        echo "<script>
        alert('Gagal menambahkan data pegawai');
        window.location.href = '../data_Pegawai.php';
        </script>";
    }
}
?>