<?php
/** @var mysqli $koneksi */
include '../../config/koneksidbpegawai.php';

if(isset($_POST['hapus']) && isset($_POST['hapus_id'])) {
    $id = $_POST['hapus_id'];
    $tanggal = isset($_POST['hapus_tanggal']) ? mysqli_real_escape_string($koneksi, $_POST['hapus_tanggal']) : null;
    
    if($tanggal) {
        $query = "DELETE FROM gaji WHERE ID_Pegawai='$id'";
    }
    if(mysqli_query($koneksi, $query)) {
        echo "<script>
        alert('Data berhasil dihapus!');
        window.location.href = '../gaji.php';
        </script>";
    } else {
        echo "<script>
        alert('Gagal hapus: " . mysqli_error($koneksi) . "');
        window.location.href = '../gaji.php';
        </script>";
    }
}
?>