<?php
/** @var mysqli $koneksi */
include '../../config/koneksidbpegawai.php';

if (isset($_POST['ID_Pegawai'])) {
    
$ID_Pegawai = $_POST['ID_Pegawai'];
$Nama = $_POST['Nama'];
$Jabatan = $_POST['jabatan'];

$query = "UPDATE identitas_pegawai SET Nama='$Nama', Jabatan='$Jabatan' WHERE ID_Pegawai='$ID_Pegawai'";

$result = mysqli_query($koneksi, $query);

if ($result) {
    echo "<script>
    alert('Jabatan pegawai berhasil diubah!');
    window.location.href = '../jabatan.php';
    </script>";
} else {
    echo "<script>
    alert('Gagal menambahkan data siswa!');
    window.location.href = '../jabatan.php';
    </script>";
}
}

?>