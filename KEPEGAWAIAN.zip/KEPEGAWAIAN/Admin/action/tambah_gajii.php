<?php
/** @var mysqli $koneksi */
include '../../config/koneksidbpegawai.php';

if(isset($_POST['simpan_gaji'])) {
    $id_pegawai =$_POST['ID_Pegawai'];
    $gaji_pokok =$_POST['gaji_pokok'];
    $tunjangan =$_POST['tunjangan'] ?? 0;
    $potongan = $_POST['potongan_absen'] ?? 0;
    $total_gaji = $_POST['total_gaji'];
    $tanggal = date('Y-m-d');
    
    $query = "SELECT Nama FROM identitas_pegawai WHERE ID_Pegawai='$id_pegawai'";
    $result = mysqli_query($koneksi, $query);
    $data_pegawai = mysqli_fetch_assoc($result);
    

    $sql = "INSERT INTO gaji (ID_Pegawai, Nama_Pegawai, Tanggal, Gaji_Perbulan, Tambahan_Gaji, Potongan_Gaji, Total_Gaji) 
            VALUES ('$id_pegawai', '{$data_pegawai['Nama']}', '$tanggal', $gaji_pokok, $tunjangan, $potongan, $total_gaji)";
    
    if(mysqli_query($koneksi, $sql)) {
        echo "<script>alert('✅ Data gaji berhasil disimpan!'); window.location.reload();</script>";
    } else {
        echo "<script>alert('❌ Error: ".mysqli_error($koneksi)."');</script>";
    }
}
?>