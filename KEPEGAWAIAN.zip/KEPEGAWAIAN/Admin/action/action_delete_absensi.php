<?php
/** @var mysqli $koneksi */
include '../../config/koneksidbpegawai.php';

if(isset($_POST['hapus']) && isset($_POST['hapus_id'])) {
    $id = $_POST['hapus_id'];
    
    $query = "DELETE FROM absensi WHERE ID_Pegawai='$id'";
    
    if(mysqli_query($koneksi, $query)) {
        echo "<script>
        alert('Data berhasil dihapus!');
        window.location.href = '../absensi.php';
        </script>";
    } else {
        echo "<script>
        alert('Gagal hapus: " . mysqli_error($koneksi) . "');
        window.location.href = '../absensi.php';
        </script>";
    }
}
?>