<?php
session_start();
include "config/koneksidbpegawai.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $Username = $_POST['Username'];
    $Password = md5($_POST['Password']);


    $sql = "SELECT * FROM karyawan WHERE Username = ? AND Password = ?";

    $stmt = mysqli_prepare($koneksi, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $Username, $Password);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    

    if (mysqli_num_rows($result) > 0) {

        $row = mysqli_fetch_assoc($result);

        $_SESSION['Username'] = $row['Username'];
        $_SESSION['Hak_Akses'] = $row['Hak_Akses'];
        $_SESSION['Nama'] = $row['Nama'];
        
        // Get ID_Pegawai from identitas_pegawai table
        $id_query = "SELECT ID_Pegawai FROM identitas_pegawai WHERE Nama = ?";
        $id_stmt = mysqli_prepare($koneksi, $id_query);
        mysqli_stmt_bind_param($id_stmt, "s", $row['Nama']);
        mysqli_stmt_execute($id_stmt);
        $id_result = mysqli_stmt_get_result($id_stmt);
        if ($id_data = mysqli_fetch_assoc($id_result)) {
            $_SESSION['ID_Pegawai'] = $id_data['ID_Pegawai'];
        }
        mysqli_stmt_close($id_stmt);

        if ($row['Hak_Akses'] == 'admin') {
            header("Location: Admin/index_Admin.php");
            exit();
        } elseif ($row['Hak_Akses'] == 'karyawan') {
            header("Location: Pegawai/index.pegawai.php");
            exit();
        } else {
            echo "Tidak ada hak akses";
            exit();
        }

    } else {

        echo "<script>
            alert('Username atau password salah!');
            window.location.href='index.php';
        </script>";
        exit();
    }
}
?>