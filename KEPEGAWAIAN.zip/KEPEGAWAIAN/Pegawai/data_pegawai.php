<?php
/** @var mysqli $koneksi */
    include "../config/koneksidbpegawai.php";
session_start();

if(!isset($_SESSION['Hak_Akses']) || $_SESSION['Hak_Akses'] != 'karyawan'){
    header("Location: ../index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">

<style>
        * { margin: 0; 
        padding: 0; 
        box-sizing: border-box; 
        }

        body { 
            font-family: 'Segoe UI'; 
            background: #f5f7fa;
        }

        .sidebar {
            position: fixed;
            width: 280px;
            height: 100vh;
            background: linear-gradient(#667eea, #02005a);
            color: white;
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
        }

        .sidebar-header h2 {
            margin-bottom: 8px;
        }

        .menu-item {
            display: block;
            padding: 18px 25px;
            color: white;
            text-decoration: none;
            font-weight: 500;
        }

        .main-content {
            margin-left: 280px;
            padding: 30px;      
        }

        .topbar {
            background: white;
            padding: 25px 35px;
            border-radius: 20px;
            margin-bottom: 35px;
            display: flex;
            align-items: center;
        }

        .topbar p {
            margin: 5px;
        }


.table-responsive {
    background: white;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    margin-top:50px;
}

.table {
    min-width: 1200px ;
}

    </style>
    </head>
<body>
     <div class="sidebar">
        <div class="sidebar-header">
            <h2> Kepegawaian</h2>
        </div>
        <div class="sidebar-menu">
            <a href="index.pegawai.php" class="menu-item active">Dashboard</a>
            <a href="data_pegawai.php" class="menu-item">Data Karyawan</a>
            <a href="absensip.php" class="menu-item">Absensi</a>
            <a href="jabatanp.php" class="menu-item">Jabatan</a>
            <a href="gajih.php" class="menu-item"> Gaji</a>
            <a href="../logout.php" class="menu-item"> Logout</a>
        </div>
    </div>

    
    <div class="main-content">
        <div class="topbar">
            <div>
                <h1>Dashboard</h1>
                <p>Selamat datang!</p>
            </div>
        </div>

    
        <h2>DATA KARYAWAN</h2>

        
           <div class="table-responsive" >
    <table class="table table-striped table-hover table-bordered">
                <thead>
                <tr>
                    <th>No</th>
                    <th>ID Pegawai</th>
                    <th>NIK</th>
                    <th>Nama</th>
                    <th>TTL</th>
                    <th>Alamat</th>
                    <th>Gender</th>
                    <th>Agama</th>
                    <th>No_Telepon</th>
                    <th>Email</th>
                    <th>Jabatan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                    $sql = "SELECT * FROM identitas_pegawai WHERE Nama = ? ORDER BY Nama ASC";
                    $stmt = mysqli_prepare($koneksi, $sql);
                    mysqli_stmt_bind_param($stmt, "s", $_SESSION['Nama']);
                    mysqli_stmt_execute($stmt);
                    $hasil = mysqli_stmt_get_result($stmt);
                    while ($data = mysqli_fetch_assoc($hasil)){
                ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $data['ID_Pegawai'] ?></td>
                        <td><?= $data['NIK'] ?></td>
                        <td><?= $data['Nama'] ?></td>
                        <td><?= $data['TTL'] ?></td>
                        <td><?= $data['Alamat'] ?></td>
                        <td><?= $data['Gender'] ?></td>
                        <td><?= $data['Agama'] ?></td>
                        <td><?= $data['No_Telepon'] ?></td>
                        <td><?= $data['Email'] ?></td>
                        <td><?= $data['Jabatan'] ?></td>
                    </tr>
                    <?php
                    }?>
            </tbody>
        </table>
</div>
</div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>