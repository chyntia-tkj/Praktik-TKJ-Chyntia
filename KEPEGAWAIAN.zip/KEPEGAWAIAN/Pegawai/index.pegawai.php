<?php
include "../config/koneksidbpegawai.php";
session_start();

if(!isset($_SESSION['Hak_Akses']) || $_SESSION['Hak_Akses'] != 'karyawan'){
    header("Location: ../index.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Kepegawaian</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

     <style>
        * { margin: 0; 
        padding: 0; 
        box-sizing: border-box; 
        }

        body { 
            font-family: 'Segoe UI'; 
            background: #f5f7fa;
        }

        .sidebar {
            position: fixed;
            width: 280px;
            height: 100vh;
            background: linear-gradient(#667eea, #02005a);
            color: white;
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
        }

        .sidebar-header h2 {
            margin-bottom: 8px;
        }

        .menu-item {
            display: block;
            padding: 18px 25px;
            color: white;
            text-decoration: none;
            font-weight: 500;
        }

        .main-content {
            margin-left: 280px;
            padding: 30px;      
        }

        .topbar {
            background: white;
            padding: 25px 35px;
            border-radius: 20px;
            margin-bottom: 35px;
            display: flex;
            align-items: center;
        }

        .topbar p {
            margin: 5px;
        }

        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
        }

        .menu-card {
            background: white;
            padding: 40px 30px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            text-align: center;
            border-left: 6px solid #667eea;
            cursor: pointer;
        }


    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <h2> Kepegawaian</h2>
        </div>
        <div class="sidebar-menu">
            <a href="index.pegawai.php" class="menu-item active">Dashboard</a>
            <a href="data_pegawai.php" class="menu-item">Data Karyawan</a>
            <a href="absensip.php" class="menu-item">Absensi</a>
            <a href="jabatanp.php" class="menu-item">Jabatan</a>
            <a href="gajih.php" class="menu-item"> Gaji</a>
            <a href="../logout.php" class="menu-item"> Logout</a>
        </div>
    </div>

    
    <div class="main-content">
        <div class="topbar">
            <div>
                <h1>Dashboard</h1>
                <p>Selamat datang!</p>
            </div>
        </div>

        <h3 align="center">Akses Pegawai </h3><br> <br>
        <div class="menu-grid">
            <div class="menu-card">
                <h3>Melihat Data Pegawai</h3>
            </div>
            <div class="menu-card">
                <h3>Mengisi Absensi</h3>
            </div>
            <div class="menu-card">
                <h3>Melihat data jabatan</h3>
            </div>
            <div class="menu-card">
                <h3>Melihat gaji</h3>
            </div>
        </div>
    </div>
</body>
</html>