 <div class="modal fade" id="tambah_absensi" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="actionp/add_absensi.php" method="POST">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title">Tambah Absensi</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Karyawan</label>
                            <input type="text" class="form-control" value="<?= $_SESSION['Nama'] ?>" disabled>
                            <input type="hidden" name="ID_Pegawai" value="<?= $_SESSION['ID_Pegawai'] ?>">
                        </div>
                        <div class="mb-3">
                        <label class="form-label">Status Kehadiran</label>
                        <select name="Status" class="form-select" required>
                            <option value="Hadir">Hadir</option>
                            <option value="Izin">Izin</option>
                            <option value="Sakit">Sakit</option>
                            <option value="Alpha">Alpha</option>
                        </select>
                    </div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>