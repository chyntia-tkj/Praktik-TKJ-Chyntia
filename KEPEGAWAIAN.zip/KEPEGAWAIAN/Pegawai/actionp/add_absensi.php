<?php
/** @var mysqli $koneksi */
include '../../config/koneksidbpegawai.php';
session_start();

if (isset($_POST['ID_Pegawai'])) {
    
    $ID_Pegawai = $_POST['ID_Pegawai'];
    $Tanggal = date('Y-m-d');
    $Status = $_POST['Status'];
    $nama_karyawan = $_SESSION['Nama'];
    
    // jam masuk otomatis saat klik hadir
    if ($Status === 'Hadir') {
        $jam_masuk = date('H:i:s');
    } else {
        $jam_masuk = '00:00:00';
    }
    

    $cek = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM absensi WHERE ID_Pegawai = '$ID_Pegawai' AND DATE(Tanggal) = '$Tanggal'");
    
    $row = mysqli_fetch_assoc($cek);
    
    if($row['total'] > 0) {
        echo "<script>
        alert('Anda sudah absen hari ini!');
        window.location.href = '../absensip.php';
        </script>";
        exit;
    }

    $query = "INSERT INTO absensi (ID_Pegawai, nama_karyawan, Tanggal, jam_masuk, jam_keluar, Status) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "isssss", $ID_Pegawai, $nama_karyawan, $Tanggal, $jam_masuk, $jam_keluar, $Status);
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        echo "<script>
        alert('Absensi berhasil ditambahkan!');
        window.location.href = '../absensip.php';
        </script>";
    } else {
        echo "<script>
        alert('Gagal!');
        window.location.href = '../absensip.php';
        </script>";
    }
}
?>