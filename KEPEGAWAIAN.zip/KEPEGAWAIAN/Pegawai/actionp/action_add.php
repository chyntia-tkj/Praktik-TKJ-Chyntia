<?php
/** @var mysqli $koneksi */
include '../../config/koneksidbpegawai.php';

if (isset($_POST['Nama'])) {
    
$NIK = $_POST['NIK'];
$Nama = $_POST['Nama'];
$TTL = $_POST['TTL'];
$Alamat = $_POST['Alamat'];
$Gender = $_POST['Gender'];
$Agama = $_POST['Agama'];
$No_Telepon = $_POST['No_Telepon'];
$Email = $_POST['Email'];
$Jabatan = $_POST['jabatan'];

$query = "INSERT INTO identitas_pegawai VALUES (null, '$NIK', '$Nama', '$TTL', '$Alamat', '$Gender', '$Agama', '$No_Telepon', '$Email', '$Jabatan')";


$result = mysqli_query($koneksi, $query);

if ($result) {
    echo "<script>
    alert('Data pegawai berhasil ditambahkan!');
    window.location.href = '../data_pegawai.php';
    </script>";
} else {
    echo "<script>
    alert('Gagal menambahkan data pegawai!');
    window.location.href = '../data_pegawai.php';
    </script>";
}
}
?>